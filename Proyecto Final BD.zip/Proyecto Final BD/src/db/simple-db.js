const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../../data/database.db');
const JSON_DB_PATH = path.join(__dirname, '../../data/database.json');

// Variable global para almacenar la BD en memoria
let inMemoryDB = {};

class SimpleDatabase {
    constructor() {
        this.db = inMemoryDB;
    }

    async initialize() {
        // Cargar datos existentes de JSON si existen
        if (fs.existsSync(JSON_DB_PATH)) {
            try {
                const jsonData = JSON.parse(fs.readFileSync(JSON_DB_PATH, 'utf8'));
                this.db = jsonData;
                console.log('✅ Base de datos cargada desde JSON');
                return;
            } catch (error) {
                console.error('Error al cargar JSON:', error);
            }
        }

        // Inicializar estructura de BD vacía
        this.db = {
            usuarios: [],
            profesores: [],
            cursos: [],
            estudiantes: [],
            espacios: [],
            equipos: [],
            asignaciones: [],
            horarios: [],
            disponibles: [],
            administrativos: [],
            inscripcion: []
        };
        
        this.saveToFile();
        console.log('✅ Nueva base de datos inicializada');
    }

    saveToFile() {
        try {
            const dir = path.dirname(JSON_DB_PATH);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            fs.writeFileSync(JSON_DB_PATH, JSON.stringify(this.db, null, 2));
        } catch (error) {
            console.error('Error al guardar BD:', error);
        }
    }

    // Métodos simples para acceder a datos
    getTable(tableName) {
        if (!this.db[tableName]) {
            this.db[tableName] = [];
        }
        return this.db[tableName];
    }

    getNextId(tableName) {
        const items = this.getTable(tableName);
        if (items.length === 0) return 1;
        return Math.max(...items.map(item => item.id || 0)) + 1;
    }

    async run(sql, params = []) {
        // Dummy implementation for compatibility
        return { lastID: 0, changes: 1 };
    }

    async get(sql, params = []) {
        return null;
    }

    async all(sql, params = []) {
        return [];
    }

    async close() {
        this.saveToFile();
        console.log('✅ Base de datos guardada');
    }
}

module.exports = SimpleDatabase;
