class Administrativo {
  constructor(id, nombre, email, rol, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
    this.rol = rol;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      email: this.email,
      rol: this.rol,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Administrativo(row.id, row.nombre, row.email, row.rol, row.createdAt);
  }
}

module.exports = Administrativo;
