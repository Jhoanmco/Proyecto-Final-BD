class Disponible {
  constructor(id, espacioId, horarioId, disponible, createdAt = new Date().toISOString()) {
    this.id = id;
    this.espacioId = espacioId;
    this.horarioId = horarioId;
    this.disponible = disponible;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      espacioId: this.espacioId,
      horarioId: this.horarioId,
      disponible: this.disponible,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Disponible(row.id, row.espacioId, row.horarioId, row.disponible, row.createdAt);
  }
}

module.exports = Disponible;
