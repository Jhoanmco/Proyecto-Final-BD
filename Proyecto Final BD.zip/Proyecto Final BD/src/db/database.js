const fs = require('fs');
const path = require('path');

class Database {
  constructor(dbPath = './data/database.json') {
    this.dbPath = dbPath;
    this.data = {
      users: [],
      profesores: [],
      cursos: [],
      estudiantes: [],
      espacios: [],
      equipos: [],
      asignaciones: [],
      horarios: [],
      disponibles: [],
      administrativos: []
    };
    this.ensureDataDir();
  }

  /**
   * Ensure data directory exists
   */
  ensureDataDir() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  /**
   * Initialize database (load from file)
   */
  init() {
    try {
      if (fs.existsSync(this.dbPath)) {
        const content = fs.readFileSync(this.dbPath, 'utf8');
        this.data = JSON.parse(content);
      } else {
        this.save();
      }
      console.log('Connected to JSON database');
    } catch (error) {
      console.error('Error loading database:', error);
      this.data = {
        users: [],
        profesores: [],
        cursos: [],
        estudiantes: [],
        espacios: [],
        equipos: [],
        asignaciones: [],
        horarios: [],
        disponibles: [],
        administrativos: []
      };
      this.save();
    }
    return this;
  }

  /**
   * Save data to file
   */
  save() {
    fs.writeFileSync(this.dbPath, JSON.stringify(this.data, null, 2));
  }

  // USUARIOS
  getAllUsers() {
    return this.data.users || [];
  }

  getUserById(id) {
    return (this.data.users || []).find(u => u.id === parseInt(id));
  }

  createUser(name, email) {
    const newUser = {
      id: (this.data.users || []).length > 0 
        ? Math.max(...(this.data.users || []).map(u => u.id)) + 1 
        : 1,
      name,
      email,
      created_at: new Date().toISOString()
    };
    if (!this.data.users) this.data.users = [];
    this.data.users.push(newUser);
    this.save();
    return newUser;
  }

  updateUser(id, name, email) {
    const user = this.getUserById(id);
    if (user) {
      user.name = name;
      user.email = email;
      this.save();
    }
    return user;
  }

  deleteUser(id) {
    const index = (this.data.users || []).findIndex(u => u.id === parseInt(id));
    if (index > -1) {
      this.data.users.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // PROFESORES
  getAllProfesores() {
    return this.data.profesores || [];
  }

  getProfesorById(id) {
    return (this.data.profesores || []).find(p => p.id === parseInt(id));
  }

  createProfesor(nombre, email, especialidad) {
    const newProfesor = {
      id: (this.data.profesores || []).length > 0 
        ? Math.max(...(this.data.profesores || []).map(p => p.id)) + 1 
        : 1,
      nombre,
      email,
      especialidad,
      createdAt: new Date().toISOString()
    };
    if (!this.data.profesores) this.data.profesores = [];
    this.data.profesores.push(newProfesor);
    this.save();
    return newProfesor;
  }

  updateProfesor(id, nombre, email, especialidad) {
    const profesor = this.getProfesorById(id);
    if (profesor) {
      profesor.nombre = nombre;
      profesor.email = email;
      profesor.especialidad = especialidad;
      this.save();
    }
    return profesor;
  }

  deleteProfesor(id) {
    const index = (this.data.profesores || []).findIndex(p => p.id === parseInt(id));
    if (index > -1) {
      this.data.profesores.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // CURSOS
  getAllCursos() {
    return this.data.cursos || [];
  }

  getCursoById(id) {
    return (this.data.cursos || []).find(c => c.id === parseInt(id));
  }

  createCurso(nombre, codigo, descripcion, profesorId) {
    const newCurso = {
      id: (this.data.cursos || []).length > 0 
        ? Math.max(...(this.data.cursos || []).map(c => c.id)) + 1 
        : 1,
      nombre,
      codigo,
      descripcion,
      profesorId,
      createdAt: new Date().toISOString()
    };
    if (!this.data.cursos) this.data.cursos = [];
    this.data.cursos.push(newCurso);
    this.save();
    return newCurso;
  }

  updateCurso(id, nombre, codigo, descripcion, profesorId) {
    const curso = this.getCursoById(id);
    if (curso) {
      curso.nombre = nombre;
      curso.codigo = codigo;
      curso.descripcion = descripcion;
      curso.profesorId = profesorId;
      this.save();
    }
    return curso;
  }

  deleteCurso(id) {
    const index = (this.data.cursos || []).findIndex(c => c.id === parseInt(id));
    if (index > -1) {
      this.data.cursos.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // ESTUDIANTES
  getAllEstudiantes() {
    return this.data.estudiantes || [];
  }

  getEstudianteById(id) {
    return (this.data.estudiantes || []).find(e => e.id === parseInt(id));
  }

  createEstudiante(nombre, email, matricula, cursoId) {
    const newEstudiante = {
      id: (this.data.estudiantes || []).length > 0 
        ? Math.max(...(this.data.estudiantes || []).map(e => e.id)) + 1 
        : 1,
      nombre,
      email,
      matricula,
      cursoId,
      createdAt: new Date().toISOString()
    };
    if (!this.data.estudiantes) this.data.estudiantes = [];
    this.data.estudiantes.push(newEstudiante);
    this.save();
    return newEstudiante;
  }

  updateEstudiante(id, nombre, email, matricula, cursoId) {
    const estudiante = this.getEstudianteById(id);
    if (estudiante) {
      estudiante.nombre = nombre;
      estudiante.email = email;
      estudiante.matricula = matricula;
      estudiante.cursoId = cursoId;
      this.save();
    }
    return estudiante;
  }

  deleteEstudiante(id) {
    const index = (this.data.estudiantes || []).findIndex(e => e.id === parseInt(id));
    if (index > -1) {
      this.data.estudiantes.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // ESPACIOS
  getAllEspacios() {
    return this.data.espacios || [];
  }

  getEspacioById(id) {
    return (this.data.espacios || []).find(e => e.id === parseInt(id));
  }

  createEspacio(nombre, ubicacion, capacidad, tipo) {
    const newEspacio = {
      id: (this.data.espacios || []).length > 0 
        ? Math.max(...(this.data.espacios || []).map(e => e.id)) + 1 
        : 1,
      nombre,
      ubicacion,
      capacidad,
      tipo,
      createdAt: new Date().toISOString()
    };
    if (!this.data.espacios) this.data.espacios = [];
    this.data.espacios.push(newEspacio);
    this.save();
    return newEspacio;
  }

  updateEspacio(id, nombre, ubicacion, capacidad, tipo) {
    const espacio = this.getEspacioById(id);
    if (espacio) {
      espacio.nombre = nombre;
      espacio.ubicacion = ubicacion;
      espacio.capacidad = capacidad;
      espacio.tipo = tipo;
      this.save();
    }
    return espacio;
  }

  deleteEspacio(id) {
    const index = (this.data.espacios || []).findIndex(e => e.id === parseInt(id));
    if (index > -1) {
      this.data.espacios.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // EQUIPOS
  getAllEquipos() {
    return this.data.equipos || [];
  }

  getEquiposById(id) {
    return (this.data.equipos || []).find(e => e.id === parseInt(id));
  }

  createEquipos(nombre, tipo, cantidad, espacioId) {
    const newEquipos = {
      id: (this.data.equipos || []).length > 0 
        ? Math.max(...(this.data.equipos || []).map(e => e.id)) + 1 
        : 1,
      nombre,
      tipo,
      cantidad,
      espacioId,
      createdAt: new Date().toISOString()
    };
    if (!this.data.equipos) this.data.equipos = [];
    this.data.equipos.push(newEquipos);
    this.save();
    return newEquipos;
  }

  updateEquipos(id, nombre, tipo, cantidad, espacioId) {
    const equipos = this.getEquiposById(id);
    if (equipos) {
      equipos.nombre = nombre;
      equipos.tipo = tipo;
      equipos.cantidad = cantidad;
      equipos.espacioId = espacioId;
      this.save();
    }
    return equipos;
  }

  deleteEquipos(id) {
    const index = (this.data.equipos || []).findIndex(e => e.id === parseInt(id));
    if (index > -1) {
      this.data.equipos.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // ASIGNACIONES
  getAllAsignaciones() {
    return this.data.asignaciones || [];
  }

  getAsignacionById(id) {
    return (this.data.asignaciones || []).find(a => a.id === parseInt(id));
  }

  createAsignacion(cursoId, espacioId) {
    const newAsignacion = {
      id: (this.data.asignaciones || []).length > 0 
        ? Math.max(...(this.data.asignaciones || []).map(a => a.id)) + 1 
        : 1,
      cursoId,
      espacioId,
      createdAt: new Date().toISOString()
    };
    if (!this.data.asignaciones) this.data.asignaciones = [];
    this.data.asignaciones.push(newAsignacion);
    this.save();
    return newAsignacion;
  }

  updateAsignacion(id, cursoId, espacioId) {
    const asignacion = this.getAsignacionById(id);
    if (asignacion) {
      asignacion.cursoId = cursoId;
      asignacion.espacioId = espacioId;
      this.save();
    }
    return asignacion;
  }

  deleteAsignacion(id) {
    const index = (this.data.asignaciones || []).findIndex(a => a.id === parseInt(id));
    if (index > -1) {
      this.data.asignaciones.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // HORARIOS
  getAllHorarios() {
    return this.data.horarios || [];
  }

  getHorarioById(id) {
    return (this.data.horarios || []).find(h => h.id === parseInt(id));
  }

  createHorario(asignacionId, diaSemana, horaInicio, horaFin) {
    const newHorario = {
      id: (this.data.horarios || []).length > 0 
        ? Math.max(...(this.data.horarios || []).map(h => h.id)) + 1 
        : 1,
      asignacionId,
      diaSemana,
      horaInicio,
      horaFin,
      createdAt: new Date().toISOString()
    };
    if (!this.data.horarios) this.data.horarios = [];
    this.data.horarios.push(newHorario);
    this.save();
    return newHorario;
  }

  updateHorario(id, asignacionId, diaSemana, horaInicio, horaFin) {
    const horario = this.getHorarioById(id);
    if (horario) {
      horario.asignacionId = asignacionId;
      horario.diaSemana = diaSemana;
      horario.horaInicio = horaInicio;
      horario.horaFin = horaFin;
      this.save();
    }
    return horario;
  }

  deleteHorario(id) {
    const index = (this.data.horarios || []).findIndex(h => h.id === parseInt(id));
    if (index > -1) {
      this.data.horarios.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // DISPONIBLES
  getAllDisponibles() {
    return this.data.disponibles || [];
  }

  getDisponibleById(id) {
    return (this.data.disponibles || []).find(d => d.id === parseInt(id));
  }

  createDisponible(espacioId, horarioId, disponible) {
    const newDisponible = {
      id: (this.data.disponibles || []).length > 0 
        ? Math.max(...(this.data.disponibles || []).map(d => d.id)) + 1 
        : 1,
      espacioId,
      horarioId,
      disponible,
      createdAt: new Date().toISOString()
    };
    if (!this.data.disponibles) this.data.disponibles = [];
    this.data.disponibles.push(newDisponible);
    this.save();
    return newDisponible;
  }

  updateDisponible(id, espacioId, horarioId, disponible) {
    const disp = this.getDisponibleById(id);
    if (disp) {
      disp.espacioId = espacioId;
      disp.horarioId = horarioId;
      disp.disponible = disponible;
      this.save();
    }
    return disp;
  }

  deleteDisponible(id) {
    const index = (this.data.disponibles || []).findIndex(d => d.id === parseInt(id));
    if (index > -1) {
      this.data.disponibles.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // ADMINISTRATIVOS
  getAllAdministrativos() {
    return this.data.administrativos || [];
  }

  getAdministrativoById(id) {
    return (this.data.administrativos || []).find(a => a.id === parseInt(id));
  }

  createAdministrativo(nombre, email, rol) {
    const newAdministrativo = {
      id: (this.data.administrativos || []).length > 0 
        ? Math.max(...(this.data.administrativos || []).map(a => a.id)) + 1 
        : 1,
      nombre,
      email,
      rol,
      createdAt: new Date().toISOString()
    };
    if (!this.data.administrativos) this.data.administrativos = [];
    this.data.administrativos.push(newAdministrativo);
    this.save();
    return newAdministrativo;
  }

  updateAdministrativo(id, nombre, email, rol) {
    const admin = this.getAdministrativoById(id);
    if (admin) {
      admin.nombre = nombre;
      admin.email = email;
      admin.rol = rol;
      this.save();
    }
    return admin;
  }

  deleteAdministrativo(id) {
    const index = (this.data.administrativos || []).findIndex(a => a.id === parseInt(id));
    if (index > -1) {
      this.data.administrativos.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  /**
   * Close database
   */
  // INSCRIPCION
  getAllInscripciones() {
    return this.data.inscripcion || [];
  }

  getInscripcionById(id) {
    return (this.data.inscripcion || []).find(i => i.id === parseInt(id));
  }

  createInscripcion(id_estudiante, id_curso) {
    const newInscripcion = {
      id: (this.data.inscripcion || []).length > 0 
        ? Math.max(...(this.data.inscripcion || []).map(i => i.id)) + 1 
        : 1,
      id_estudiante: parseInt(id_estudiante),
      id_curso: parseInt(id_curso)
    };
    if (!this.data.inscripcion) this.data.inscripcion = [];
    this.data.inscripcion.push(newInscripcion);
    this.save();
    return newInscripcion;
  }

  updateInscripcion(id, id_estudiante, id_curso) {
    const inscripcion = this.getInscripcionById(id);
    if (!inscripcion) return null;
    
    inscripcion.id_estudiante = parseInt(id_estudiante);
    inscripcion.id_curso = parseInt(id_curso);
    this.save();
    return inscripcion;
  }

  deleteInscripcion(id) {
    const index = (this.data.inscripcion || []).findIndex(i => i.id === parseInt(id));
    if (index === -1) return false;
    
    this.data.inscripcion.splice(index, 1);
    this.save();
    return true;
  }

  // DISPONIBILIDAD - Calcula la disponibilidad real de un espacio en un horario
  calculateRealAvailability(id_espacio, id_horario) {
    const espacio = this.getEspacioById(id_espacio);
    const horario = this.getHorarioById(id_horario);
    
    if (!espacio || !horario) return false;

    // Criterio 1: El espacio debe estar en estado "Disponible"
    if (espacio.estado !== 'Disponible') {
      return false;
    }

    // Criterio 2: Verificar si hay una asignación para este espacio en este horario
    // El horario tiene un id_asignacion que vincula a una asignación
    // Si el horario tiene asignación y esa asignación es para este espacio, no está disponible
    if (horario.id_asignacion) {
      const asignacion = this.getAsignacionById(horario.id_asignacion);
      if (asignacion && asignacion.id_espacio === parseInt(id_espacio)) {
        return false;
      }
    }

    // Si pasa todos los criterios, está disponible
    return true;
  }

  // Método auxiliar para obtener espacio por ID
  getEspacioById(id) {
    return (this.data.espacios || []).find(e => e.id === parseInt(id));
  }

  // Método auxiliar para obtener horario por ID
  getHorarioById(id) {
    return (this.data.horarios || []).find(h => h.id === parseInt(id));
  }

  // Obtener todas las disponibilidades calculadas en tiempo real
  getAllDisponiblesCalculadas() {
    return (this.data.disponibles || []).map(disp => {
      const disponibilidadReal = this.calculateRealAvailability(disp.id_espacio, disp.id_horario);
      const razon = this.getDisponibilityReason(disp.id_espacio, disp.id_horario);
      
      return {
        ...disp,
        disponible: disponibilidadReal,
        razon: razon
      };
    }).filter(disp => disp.disponible === true); // Solo mostrar espacios disponibles
  }

  // Obtener la razón por la cual un espacio no está disponible
  getDisponibilityReason(id_espacio, id_horario) {
    const espacio = this.getEspacioById(id_espacio);
    const horario = this.getHorarioById(id_horario);
    
    if (!espacio) return 'Espacio no encontrado';
    if (!horario) return 'Horario no encontrado';
    
    if (espacio.estado !== 'Disponible') {
      return `Espacio en estado: ${espacio.estado}`;
    }

    if (horario.id_asignacion) {
      const asignacion = this.getAsignacionById(horario.id_asignacion);
      if (asignacion && asignacion.id_espacio === parseInt(id_espacio)) {
        return 'Horario ocupado por asignación';
      }
    }

    return 'Disponible';
  }

  close() {
    console.log('Database connection closed');
  }
}

module.exports = Database;
