const Database = require('./src/db/database');

try {
  const db = new Database('./data/database.json');
  console.log('DB creada');
  db.init();
  console.log('DB inicializada');
  console.log('Data:', db.data);
  const profs = db.getAllProfesores();
  console.log('Profesores:', profs);
  console.log('Total de profesores:', profs.length);
} catch (err) {
  console.error('Error:', err);
}
