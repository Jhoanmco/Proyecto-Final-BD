const Curso = require('../models/Curso');

class CursoController {
  constructor(database) {
    this.db = database;
  }

  getAllCursos() {
    const rows = this.db.getAllCursos();
    return rows.map(row => Curso.fromDatabase(row));
  }

  getCursoById(id) {
    const row = this.db.getCursoById(id);
    return row ? Curso.fromDatabase(row) : null;
  }

  createCurso(nombre_curso, codigo, num_estudiantes, id_profesor) {
    const curso = this.db.createCurso(nombre_curso, codigo, num_estudiantes, id_profesor);
    return Curso.fromDatabase(curso);
  }

  updateCurso(id, nombre_curso, codigo, num_estudiantes, id_profesor) {
    const curso = this.db.updateCurso(id, nombre_curso, codigo, num_estudiantes, id_profesor);
    return curso ? Curso.fromDatabase(curso) : null;
  }

  deleteCurso(id) {
    const success = this.db.deleteCurso(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = CursoController;
