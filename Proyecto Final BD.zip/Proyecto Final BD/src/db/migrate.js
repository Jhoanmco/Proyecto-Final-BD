const fs = require('fs');
const path = require('path');

const JSON_PATH = path.join(__dirname, '../../data/database.json');
const DB_PATH = path.join(__dirname, '../../data/database.db');

async function migrateJsonToSqlite(sqliteDb) {
    // Verificar si ya existe data migrada (si hay profesores, no migrar)
    const existingData = await sqliteDb.get('SELECT COUNT(*) as count FROM profesores');
    
    if (existingData && existingData.count > 0) {
        console.log('✅ Base de datos ya contiene datos, omitiendo migración');
        return false;
    }

    // Verificar si existe el archivo JSON
    if (!fs.existsSync(JSON_PATH)) {
        console.log('⚠️  No se encontró archivo JSON, creando base de datos vacía');
        return false;
    }

    try {
        const jsonData = JSON.parse(fs.readFileSync(JSON_PATH, 'utf8'));
        console.log('📤 Iniciando migración de datos JSON a SQLite...');

        // Migrar Profesores
        if (jsonData.profesores && jsonData.profesores.length > 0) {
            for (const prof of jsonData.profesores) {
                await sqliteDb.run(
                    `INSERT INTO profesores (id, nombre, email, telefono, numero_documento, departamento, especialidad, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [prof.id, prof.nombre, prof.email, prof.telefono || '', prof.numero_documento || '', prof.departamento || '', prof.especialidad || '', prof.activo !== false ? 1 : 0, prof.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.profesores.length} profesores migrados`);
        }

        // Migrar Cursos
        if (jsonData.cursos && jsonData.cursos.length > 0) {
            for (const curso of jsonData.cursos) {
                await sqliteDb.run(
                    `INSERT INTO cursos (id, nombre_curso, codigo, num_estudiantes, id_profesor, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)`,
                    [curso.id, curso.nombre_curso, curso.codigo, curso.num_estudiantes || 0, curso.id_profesor || 1, curso.activo !== false ? 1 : 0, curso.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.cursos.length} cursos migrados`);
        }

        // Migrar Estudiantes
        if (jsonData.estudiantes && jsonData.estudiantes.length > 0) {
            for (const est of jsonData.estudiantes) {
                await sqliteDb.run(
                    `INSERT INTO estudiantes (id, nombre, numero_documento, curso, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?)`,
                    [est.id, est.nombre, est.numero_documento, est.curso || '', est.activo !== false ? 1 : 0, est.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.estudiantes.length} estudiantes migrados`);
        }

        // Migrar Espacios
        if (jsonData.espacios && jsonData.espacios.length > 0) {
            for (const espacio of jsonData.espacios) {
                await sqliteDb.run(
                    `INSERT INTO espacios (id, nombre, tipo, capacidad, ubicacion, estado, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    [espacio.id, espacio.nombre, espacio.tipo, espacio.capacidad, espacio.ubicacion || '', espacio.estado || 'Disponible', espacio.activo !== false ? 1 : 0, espacio.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.espacios.length} espacios migrados`);
        }

        // Migrar Equipos
        if (jsonData.equipos && jsonData.equipos.length > 0) {
            for (const equipo of jsonData.equipos) {
                await sqliteDb.run(
                    `INSERT INTO equipos (id, nombre, tipo, serie, estado, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)`,
                    [equipo.id, equipo.nombre, equipo.tipo, equipo.serie || '', equipo.estado !== false ? 1 : 0, equipo.activo !== false ? 1 : 0, equipo.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.equipos.length} equipos migrados`);
        }

        // Migrar Administrativos
        if (jsonData.administrativos && jsonData.administrativos.length > 0) {
            for (const admin of jsonData.administrativos) {
                await sqliteDb.run(
                    `INSERT INTO administrativos (id, nombre, email, telefono, departamento, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)`,
                    [admin.id, admin.nombre, admin.email || '', admin.telefono || '', admin.departamento || '', admin.activo !== false ? 1 : 0, admin.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.administrativos.length} administrativos migrados`);
        }

        // Migrar Asignaciones
        if (jsonData.asignaciones && jsonData.asignaciones.length > 0) {
            for (const asignacion of jsonData.asignaciones) {
                await sqliteDb.run(
                    `INSERT INTO asignaciones (id, id_espacio, id_curso, id_profesor, id_estudiante, id_administrativo, fecha_asignacion, estado, tipo_solicitnte, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [asignacion.id, asignacion.id_espacio, asignacion.id_curso, asignacion.id_profesor, asignacion.id_estudiante, asignacion.id_administrativo, asignacion.fecha_asignacion || '', asignacion.estado || 'Activa', asignacion.tipo_solicitnte || '', asignacion.activo !== false ? 1 : 0, asignacion.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.asignaciones.length} asignaciones migradas`);
        }

        // Migrar Horarios
        if (jsonData.horarios && jsonData.horarios.length > 0) {
            for (const horario of jsonData.horarios) {
                await sqliteDb.run(
                    `INSERT INTO horarios (id, id_asignacion, id_espacio, id_profesor, dia, hora_inicio, hora_fin, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [horario.id, horario.id_asignacion || 0, horario.id_espacio || 0, horario.id_profesor || 0, horario.dia || '', horario.hora_inicio || '', horario.hora_fin || '', horario.activo !== false ? 1 : 0, horario.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.horarios.length} horarios migrados`);
        }

        // Migrar Disponibles
        if (jsonData.disponibles && jsonData.disponibles.length > 0) {
            for (const disponible of jsonData.disponibles) {
                await sqliteDb.run(
                    `INSERT INTO disponibles (id, id_espacio, dia, hora_inicio, hora_fin, razon, activo, createdAt) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    [disponible.id, disponible.id_espacio || 0, disponible.dia || '', disponible.hora_inicio || '', disponible.hora_fin || '', disponible.razon || '', disponible.activo !== false ? 1 : 0, disponible.createdAt || new Date().toISOString()]
                );
            }
            console.log(`✅ ${jsonData.disponibles.length} disponibles migrados`);
        }

        // Migrar Inscripción
        if (jsonData.inscripcion && jsonData.inscripcion.length > 0) {
            for (const insc of jsonData.inscripcion) {
                await sqliteDb.run(
                    `INSERT INTO inscripcion (id, id_estudiante, id_curso, fecha_inscripcion, activo) 
                     VALUES (?, ?, ?, ?, ?)`,
                    [insc.id, insc.id_estudiante, insc.id_curso, insc.fecha_inscripcion || new Date().toISOString(), insc.activo !== false ? 1 : 0]
                );
            }
            console.log(`✅ ${jsonData.inscripcion.length} inscripciones migradas`);
        }

        console.log('\n✅ ¡MIGRACIÓN COMPLETADA EXITOSAMENTE!');
        console.log('📊 Los datos JSON han sido convertidos a SQLite');
        console.log('💾 Base de datos: ' + DB_PATH);
        return true;

    } catch (error) {
        console.error('❌ Error durante la migración:', error);
        throw error;
    }
}

module.exports = { migrateJsonToSqlite };
