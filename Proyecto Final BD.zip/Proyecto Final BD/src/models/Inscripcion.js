class Inscripcion {
  constructor(id, id_estudiante, id_curso, createdAt = new Date().toISOString()) {
    this.id = id;
    this.id_estudiante = id_estudiante;
    this.id_curso = id_curso;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      id_estudiante: this.id_estudiante,
      id_curso: this.id_curso,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Inscripcion(row.id, row.id_estudiante, row.id_curso, row.createdAt);
  }
}

module.exports = Inscripcion;
