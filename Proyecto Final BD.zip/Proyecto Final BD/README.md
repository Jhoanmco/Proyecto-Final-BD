# Database Interface - JavaScript

Una interfaz moderna para gestionar bases de datos usando JavaScript, Node.js y Express. Incluye módulos completos para gestionar profesores, cursos, estudiantes, espacios, equipos y asignaciones.

## Características

- ✅ API REST completa para operaciones CRUD
- ✅ JSON como almacenamiento de datos (sin dependencias de compilación)
- ✅ Arquitectura modular y escalable
- ✅ Múltiples entidades: Profesores, Cursos, Estudiantes, Espacios, Equipos, etc.
- ✅ Controladores de base de datos abstraídos
- ✅ Modelos de datos bien estructurados

## Estructura del Proyecto

```
src/
├── db/                          # Capa de base de datos
│   └── database.js              # Clase Database con métodos CRUD
├── models/                      # Modelos de datos
│   ├── User.js
│   ├── Profesor.js
│   ├── Curso.js
│   ├── Estudiante.js
│   ├── Espacio.js
│   ├── Equipos.js
│   ├── Asignacion.js
│   ├── Horario.js
│   ├── Disponible.js
│   └── Administrativo.js
├── api/                         # Capa de API REST
│   ├── routes.js                # Rutas de la API
│   ├── userController.js
│   ├── profesorController.js
│   ├── cursoController.js
│   ├── estudianteController.js
│   ├── espacioController.js
│   ├── equiposController.js
│   ├── asignacionController.js
│   ├── horarioController.js
│   ├── disponibleController.js
│   └── administrativoController.js
├── utils/                       # Utilidades
│   └── schema.js                # Esquema de base de datos
└── index.js                     # Punto de entrada
```

## Instalación

1. Instala las dependencias:
```bash
npm install
```

2. Crea un archivo `.env` basado en `.env.example`:
```bash
copy .env.example .env
```

3. Inicia el servidor:
```bash
npm start
```

Para desarrollo con auto-reload:
```bash
npm run dev
```

## API Endpoints

### Usuarios (Legacy)
- `GET /api/users` - Obtener todos los usuarios
- `GET /api/users/:id` - Obtener un usuario por ID
- `POST /api/users` - Crear un nuevo usuario
- `PUT /api/users/:id` - Actualizar un usuario
- `DELETE /api/users/:id` - Eliminar un usuario

### Profesores
- `GET /api/profesores` - Obtener todos los profesores
- `GET /api/profesores/:id` - Obtener un profesor por ID
- `POST /api/profesores` - Crear un nuevo profesor
- `PUT /api/profesores/:id` - Actualizar un profesor
- `DELETE /api/profesores/:id` - Eliminar un profesor

### Cursos
- `GET /api/cursos` - Obtener todos los cursos
- `GET /api/cursos/:id` - Obtener un curso por ID
- `POST /api/cursos` - Crear un nuevo curso
- `PUT /api/cursos/:id` - Actualizar un curso
- `DELETE /api/cursos/:id` - Eliminar un curso

### Estudiantes
- `GET /api/estudiantes` - Obtener todos los estudiantes
- `GET /api/estudiantes/:id` - Obtener un estudiante por ID
- `POST /api/estudiantes` - Crear un nuevo estudiante
- `PUT /api/estudiantes/:id` - Actualizar un estudiante
- `DELETE /api/estudiantes/:id` - Eliminar un estudiante

### Espacios
- `GET /api/espacios` - Obtener todos los espacios
- `GET /api/espacios/:id` - Obtener un espacio por ID
- `POST /api/espacios` - Crear un nuevo espacio
- `PUT /api/espacios/:id` - Actualizar un espacio
- `DELETE /api/espacios/:id` - Eliminar un espacio

### Equipos
- `GET /api/equipos` - Obtener todos los equipos
- `GET /api/equipos/:id` - Obtener un equipo por ID
- `POST /api/equipos` - Crear nuevo equipo
- `PUT /api/equipos/:id` - Actualizar equipo
- `DELETE /api/equipos/:id` - Eliminar equipo

### Asignaciones
- `GET /api/asignaciones` - Obtener todas las asignaciones
- `GET /api/asignaciones/:id` - Obtener una asignación por ID
- `POST /api/asignaciones` - Crear nueva asignación
- `PUT /api/asignaciones/:id` - Actualizar asignación
- `DELETE /api/asignaciones/:id` - Eliminar asignación

### Horarios
- `GET /api/horarios` - Obtener todos los horarios
- `GET /api/horarios/:id` - Obtener un horario por ID
- `POST /api/horarios` - Crear nuevo horario
- `PUT /api/horarios/:id` - Actualizar horario
- `DELETE /api/horarios/:id` - Eliminar horario

### Disponibles
- `GET /api/disponibles` - Obtener todos los disponibles
- `GET /api/disponibles/:id` - Obtener un disponible por ID
- `POST /api/disponibles` - Crear nuevo disponible
- `PUT /api/disponibles/:id` - Actualizar disponible
- `DELETE /api/disponibles/:id` - Eliminar disponible

### Administrativos
- `GET /api/administrativos` - Obtener todos los administrativos
- `GET /api/administrativos/:id` - Obtener un administrativo por ID
- `POST /api/administrativos` - Crear nuevo administrativo
- `PUT /api/administrativos/:id` - Actualizar administrativo
- `DELETE /api/administrativos/:id` - Eliminar administrativo

### Salud del servidor
- `GET /api/health` - Verificar estado del servidor

## Ejemplos de uso

### Crear un Profesor
```bash
$uri = "http://localhost:3000/api/profesores"
$body = @{ 
  nombre = "Dr. Juan Pérez"
  email = "juan.perez@example.com"
  especialidad = "Matemáticas"
} | ConvertTo-Json
Invoke-WebRequest -Uri $uri -Method Post -Body $body -ContentType "application/json"
```

### Crear un Curso
```bash
$uri = "http://localhost:3000/api/cursos"
$body = @{ 
  nombre = "Cálculo I"
  codigo = "MAT101"
  descripcion = "Introducción al Cálculo"
  profesorId = 1
} | ConvertTo-Json
Invoke-WebRequest -Uri $uri -Method Post -Body $body -ContentType "application/json"
```

### Crear un Espacio
```bash
$uri = "http://localhost:3000/api/espacios"
$body = @{ 
  nombre = "Aula 101"
  ubicacion = "Piso 1"
  capacidad = 30
  tipo = "Salón"
} | ConvertTo-Json
Invoke-WebRequest -Uri $uri -Method Post -Body $body -ContentType "application/json"
```

### Crear un Estudiante
```bash
$uri = "http://localhost:3000/api/estudiantes"
$body = @{ 
  nombre = "Carlos López"
  email = "carlos@example.com"
  matricula = "EST001"
  cursoId = 1
} | ConvertTo-Json
Invoke-WebRequest -Uri $uri -Method Post -Body $body -ContentType "application/json"
```

## Variables de Entorno

- `DB_PATH` - Ruta del archivo de la base de datos (default: `./data/database.json`)
- `PORT` - Puerto del servidor (default: `3000`)
- `NODE_ENV` - Ambiente (development, production)

## Datos

Los datos se guardan automáticamente en `data/database.json` en formato JSON.

## Licencia

MIT
