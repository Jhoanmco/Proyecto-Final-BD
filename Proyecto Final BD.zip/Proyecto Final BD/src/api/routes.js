const express = require('express');
const UserController = require('./userController');
const ProfesorController = require('./profesorController');
const CursoController = require('./cursoController');
const EstudianteController = require('./estudianteController');
const EspacioController = require('./espacioController');
const EquiposController = require('./equiposController');
const AsignacionController = require('./asignacionController');
const HorarioController = require('./horarioController');
const DisponibleController = require('./disponibleController');
const AdministrativoController = require('./administrativoController');

function setupRoutes(app, database) {
  // Instantiate all controllers
  const userController = new UserController(database);
  const profesorController = new ProfesorController(database);
  const cursoController = new CursoController(database);
  const estudianteController = new EstudianteController(database);
  const espacioController = new EspacioController(database);
  const equiposController = new EquiposController(database);
  const asignacionController = new AsignacionController(database);
  const horarioController = new HorarioController(database);
  const disponibleController = new DisponibleController(database);
  const administrativoController = new AdministrativoController(database);

  // USERS endpoints
  app.get('/api/users', (req, res) => {
    try {
      const users = userController.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/users/:id', (req, res) => {
    try {
      const user = userController.getUserById(req.params.id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/users', (req, res) => {
    try {
      const { name, email } = req.body;
      if (!name || !email) {
        return res.status(400).json({ error: 'Name and email are required' });
      }
      const user = userController.createUser(name, email);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/users/:id', (req, res) => {
    try {
      const { name, email } = req.body;
      const user = userController.updateUser(req.params.id, name, email);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/users/:id', (req, res) => {
    try {
      const result = userController.deleteUser(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // PROFESORES endpoints
  app.get('/api/profesores', (req, res) => {
    try {
      const profesores = database.getAllProfesores();
      res.json(profesores);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/profesores/:id', (req, res) => {
    try {
      const profesor = profesorController.getProfesorById(req.params.id);
      if (!profesor) {
        return res.status(404).json({ error: 'Profesor not found' });
      }
      res.json(profesor);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/profesores', (req, res) => {
    try {
      const { nombre, email, telefono, numero_documento, departamento, especialidad } = req.body;
      if (!nombre || !email) {
        return res.status(400).json({ error: 'Nombre y email son requeridos' });
      }
      const profesor = profesorController.createProfesor(nombre, email, telefono || '', numero_documento || '', departamento || '', especialidad || '');
      res.status(201).json(profesor);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/profesores/:id', (req, res) => {
    try {
      const { nombre, email, telefono, numero_documento, departamento, especialidad } = req.body;
      const profesor = profesorController.updateProfesor(req.params.id, nombre, email, telefono || '', numero_documento || '', departamento || '', especialidad || '');
      res.json(profesor);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/profesores/:id', (req, res) => {
    try {
      const result = profesorController.deleteProfesor(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // CURSOS endpoints
  app.get('/api/cursos', (req, res) => {
    try {
      const cursos = database.getAllCursos();
      res.json(cursos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/cursos/:id', (req, res) => {
    try {
      const curso = cursoController.getCursoById(req.params.id);
      if (!curso) {
        return res.status(404).json({ error: 'Curso not found' });
      }
      res.json(curso);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/cursos', (req, res) => {
    try {
      const { nombre_curso, codigo, num_estudiantes, id_profesor } = req.body;
      if (!nombre_curso || !codigo) {
        return res.status(400).json({ error: 'Nombre del curso y código son requeridos' });
      }
      const curso = cursoController.createCurso(nombre_curso, codigo, num_estudiantes || 0, id_profesor || 1);
      res.status(201).json(curso);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/cursos/:id', (req, res) => {
    try {
      const { nombre_curso, codigo, num_estudiantes, id_profesor } = req.body;
      const curso = cursoController.updateCurso(req.params.id, nombre_curso, codigo, num_estudiantes || 0, id_profesor || 1);
      res.json(curso);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/cursos/:id', (req, res) => {
    try {
      const result = cursoController.deleteCurso(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // ESTUDIANTES endpoints
  app.get('/api/estudiantes', (req, res) => {
    try {
      const estudiantes = database.getAllEstudiantes();
      res.json(estudiantes);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/estudiantes/:id', (req, res) => {
    try {
      const estudiante = estudianteController.getEstudianteById(req.params.id);
      if (!estudiante) {
        return res.status(404).json({ error: 'Estudiante not found' });
      }
      res.json(estudiante);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/estudiantes', (req, res) => {
    try {
      const { nombre, numero_documento, curso } = req.body;
      if (!nombre || !numero_documento || !curso) {
        return res.status(400).json({ error: 'Nombre, numero_documento and curso are required' });
      }
      const estudiante = estudianteController.createEstudiante(nombre, numero_documento, curso);
      res.status(201).json(estudiante);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/estudiantes/:id', (req, res) => {
    try {
      const { nombre, numero_documento, curso } = req.body;
      const estudiante = estudianteController.updateEstudiante(req.params.id, nombre, numero_documento, curso);
      res.json(estudiante);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/estudiantes/:id', (req, res) => {
    try {
      const result = estudianteController.deleteEstudiante(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // ESPACIOS endpoints
  app.get('/api/espacios', (req, res) => {
    try {
      const espacios = database.getAllEspacios();
      res.json(espacios);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/espacios/:id', (req, res) => {
    try {
      const espacio = espacioController.getEspacioById(req.params.id);
      if (!espacio) {
        return res.status(404).json({ error: 'Espacio not found' });
      }
      res.json(espacio);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/espacios', (req, res) => {
    try {
      const { nombre, ubicacion, capacidad, tipo } = req.body;
      if (!nombre || !ubicacion || !capacidad || !tipo) {
        return res.status(400).json({ error: 'Nombre, ubicacion, capacidad and tipo are required' });
      }
      const espacio = espacioController.createEspacio(nombre, ubicacion, capacidad, tipo);
      res.status(201).json(espacio);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/espacios/:id', (req, res) => {
    try {
      const { nombre, ubicacion, capacidad, tipo } = req.body;
      const espacio = espacioController.updateEspacio(req.params.id, nombre, ubicacion, capacidad, tipo);
      res.json(espacio);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/espacios/:id', (req, res) => {
    try {
      const result = espacioController.deleteEspacio(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // EQUIPOS endpoints
  app.get('/api/equipos', (req, res) => {
    try {
      const equipos = database.getAllEquipos();
      res.json(equipos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/equipos/:id', (req, res) => {
    try {
      const equipo = equiposController.getEquiposById(req.params.id);
      if (!equipo) {
        return res.status(404).json({ error: 'Equipo not found' });
      }
      res.json(equipo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/equipos', (req, res) => {
    try {
      const { nombre, tipo, cantidad, espacioId } = req.body;
      if (!nombre || !tipo || !cantidad || !espacioId) {
        return res.status(400).json({ error: 'Nombre, tipo, cantidad and espacioId are required' });
      }
      const equipo = equiposController.createEquipos(nombre, tipo, cantidad, espacioId);
      res.status(201).json(equipo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/equipos/:id', (req, res) => {
    try {
      const { nombre, tipo, cantidad, espacioId } = req.body;
      const equipo = equiposController.updateEquipos(req.params.id, nombre, tipo, cantidad, espacioId);
      res.json(equipo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/equipos/:id', (req, res) => {
    try {
      const result = equiposController.deleteEquipos(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // ASIGNACIONES endpoints
  app.get('/api/asignaciones', (req, res) => {
    try {
      const asignaciones = database.getAllAsignaciones();
      res.json(asignaciones);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/asignaciones/:id', (req, res) => {
    try {
      const asignacion = asignacionController.getAsignacionById(req.params.id);
      if (!asignacion) {
        return res.status(404).json({ error: 'Asignacion not found' });
      }
      res.json(asignacion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/asignaciones', (req, res) => {
    try {
      const { id_espacio, id_curso, id_profesor, id_estudiante, id_administrativo, fecha_asignacion, estado, tipo_solicitnte } = req.body;
      if (!id_espacio || !id_curso || !id_profesor || !id_estudiante || !id_administrativo || !fecha_asignacion) {
        return res.status(400).json({ error: 'All required fields must be provided' });
      }
      const asignacion = asignacionController.createAsignacion(id_espacio, id_curso, id_profesor, id_estudiante, id_administrativo, fecha_asignacion, estado, tipo_solicitnte);
      res.status(201).json(asignacion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/asignaciones/:id', (req, res) => {
    try {
      const { cursoId, espacioId } = req.body;
      const asignacion = asignacionController.updateAsignacion(req.params.id, cursoId, espacioId);
      res.json(asignacion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/asignaciones/:id', (req, res) => {
    try {
      const result = asignacionController.deleteAsignacion(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // HORARIOS endpoints
  app.get('/api/horarios', (req, res) => {
    try {
      const horarios = database.getAllHorarios();
      res.json(horarios);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/horarios/:id', (req, res) => {
    try {
      const horario = horarioController.getHorarioById(req.params.id);
      if (!horario) {
        return res.status(404).json({ error: 'Horario not found' });
      }
      res.json(horario);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/horarios', (req, res) => {
    try {
      const { asignacionId, diaSemana, horaInicio, horaFin } = req.body;
      if (!asignacionId || !diaSemana || !horaInicio || !horaFin) {
        return res.status(400).json({ error: 'AsignacionId, diaSemana, horaInicio and horaFin are required' });
      }
      const horario = horarioController.createHorario(asignacionId, diaSemana, horaInicio, horaFin);
      res.status(201).json(horario);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/horarios/:id', (req, res) => {
    try {
      const { asignacionId, diaSemana, horaInicio, horaFin } = req.body;
      const horario = horarioController.updateHorario(req.params.id, asignacionId, diaSemana, horaInicio, horaFin);
      res.json(horario);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/horarios/:id', (req, res) => {
    try {
      const result = horarioController.deleteHorario(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // DISPONIBLES endpoints
  app.get('/api/disponibles', (req, res) => {
    try {
      const disponibles = database.getAllDisponiblesCalculadas();
      res.json(disponibles);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/disponibles/:id', (req, res) => {
    try {
      const disponible = disponibleController.getDisponibleById(req.params.id);
      if (!disponible) {
        return res.status(404).json({ error: 'Disponible not found' });
      }
      res.json(disponible);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/disponibles', (req, res) => {
    try {
      const { espacioId, horarioId, disponible } = req.body;
      if (espacioId === undefined || horarioId === undefined || disponible === undefined) {
        return res.status(400).json({ error: 'EspacioId, horarioId and disponible are required' });
      }
      const disp = disponibleController.createDisponible(espacioId, horarioId, disponible);
      res.status(201).json(disp);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/disponibles/:id', (req, res) => {
    try {
      const { espacioId, horarioId, disponible } = req.body;
      const disp = disponibleController.updateDisponible(req.params.id, espacioId, horarioId, disponible);
      res.json(disp);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/disponibles/:id', (req, res) => {
    try {
      const result = disponibleController.deleteDisponible(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // ADMINISTRATIVOS endpoints
  app.get('/api/administrativos', (req, res) => {
    try {
      const administrativos = database.getAllAdministrativos();
      res.json(administrativos);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/administrativos/:id', (req, res) => {
    try {
      const administrativo = administrativoController.getAdministrativoById(req.params.id);
      if (!administrativo) {
        return res.status(404).json({ error: 'Administrativo not found' });
      }
      res.json(administrativo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/administrativos', (req, res) => {
    try {
      const { nombre, email, rol } = req.body;
      if (!nombre || !email || !rol) {
        return res.status(400).json({ error: 'Nombre, email and rol are required' });
      }
      const administrativo = administrativoController.createAdministrativo(nombre, email, rol);
      res.status(201).json(administrativo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/administrativos/:id', (req, res) => {
    try {
      const { nombre, email, rol } = req.body;
      const administrativo = administrativoController.updateAdministrativo(req.params.id, nombre, email, rol);
      res.json(administrativo);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/administrativos/:id', (req, res) => {
    try {
      const result = administrativoController.deleteAdministrativo(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // INSCRIPCION endpoints
  app.get('/api/inscripcion', (req, res) => {
    try {
      const inscripciones = database.getAllInscripciones();
      res.json(inscripciones);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/inscripcion/:id', (req, res) => {
    try {
      const inscripcion = database.getInscripcionById(req.params.id);
      if (!inscripcion) {
        return res.status(404).json({ error: 'Inscripción not found' });
      }
      res.json(inscripcion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/inscripcion', (req, res) => {
    try {
      const { id_estudiante, id_curso } = req.body;
      if (!id_estudiante || !id_curso) {
        return res.status(400).json({ error: 'id_estudiante and id_curso are required' });
      }
      const inscripcion = database.createInscripcion(id_estudiante, id_curso);
      res.status(201).json(inscripcion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/inscripcion/:id', (req, res) => {
    try {
      const { id_estudiante, id_curso } = req.body;
      const inscripcion = database.updateInscripcion(req.params.id, id_estudiante, id_curso);
      if (!inscripcion) {
        return res.status(404).json({ error: 'Inscripción not found' });
      }
      res.json(inscripcion);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/inscripcion/:id', (req, res) => {
    try {
      const success = database.deleteInscripcion(req.params.id);
      res.json({ success, id: parseInt(req.params.id) });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
}

module.exports = setupRoutes;
