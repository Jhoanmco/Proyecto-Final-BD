const Asignacion = require('../models/Asignacion');

class AsignacionController {
  constructor(database) {
    this.db = database;
  }

  getAllAsignaciones() {
    const rows = this.db.getAllAsignaciones();
    return rows.map(row => Asignacion.fromDatabase(row));
  }

  getAsignacionById(id) {
    const row = this.db.getAsignacionById(id);
    return row ? Asignacion.fromDatabase(row) : null;
  }

  createAsignacion(id_espacio, id_curso, id_profesor, id_estudiante, id_administrativo, fecha_asignacion, estado, tipo_solicitnte) {
    const asignacion = this.db.createAsignacion(id_espacio, id_curso, id_profesor, id_estudiante, id_administrativo, fecha_asignacion, estado, tipo_solicitnte);
    return Asignacion.fromDatabase(asignacion);
  }

  updateAsignacion(id, cursoId, espacioId) {
    const asignacion = this.db.updateAsignacion(id, cursoId, espacioId);
    return asignacion ? Asignacion.fromDatabase(asignacion) : null;
  }

  deleteAsignacion(id) {
    const success = this.db.deleteAsignacion(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = AsignacionController;
