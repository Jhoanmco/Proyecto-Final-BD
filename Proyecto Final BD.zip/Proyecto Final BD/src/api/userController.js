const User = require('../models/User');

class UserController {
  constructor(database) {
    this.db = database;
  }

  /**
   * Get all users
   */
  getAllUsers() {
    const rows = this.db.getAllUsers();
    return rows.map(row => User.fromDatabase(row));
  }

  /**
   * Get user by ID
   */
  getUserById(id) {
    const row = this.db.getUserById(id);
    return row ? User.fromDatabase(row) : null;
  }

  /**
   * Create new user
   */
  createUser(name, email) {
    const user = this.db.createUser(name, email);
    return User.fromDatabase(user);
  }

  /**
   * Update user
   */
  updateUser(id, name, email) {
    const user = this.db.updateUser(id, name, email);
    return user ? User.fromDatabase(user) : null;
  }

  /**
   * Delete user
   */
  deleteUser(id) {
    const success = this.db.deleteUser(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = UserController;
