class Espacio {
  constructor(id, nombre, ubicacion, capacidad, tipo, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.ubicacion = ubicacion;
    this.capacidad = capacidad;
    this.tipo = tipo;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      ubicacion: this.ubicacion,
      capacidad: this.capacidad,
      tipo: this.tipo,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Espacio(row.id, row.nombre, row.ubicacion, row.capacidad, row.tipo, row.createdAt);
  }
}

module.exports = Espacio;
