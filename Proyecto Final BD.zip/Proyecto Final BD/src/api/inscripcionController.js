const Inscripcion = require('../models/Inscripcion');

class InscripcionController {
  constructor(database) {
    this.db = database;
  }

  getAllInscripciones() {
    const rows = this.db.getAllInscripciones();
    return rows.map(row => Inscripcion.fromDatabase(row));
  }

  getInscripcionById(id) {
    const row = this.db.getInscripcionById(id);
    return row ? Inscripcion.fromDatabase(row) : null;
  }

  createInscripcion(id_estudiante, id_curso) {
    const inscripcion = this.db.createInscripcion(id_estudiante, id_curso);
    return Inscripcion.fromDatabase(inscripcion);
  }

  updateInscripcion(id, id_estudiante, id_curso) {
    const inscripcion = this.db.updateInscripcion(id, id_estudiante, id_curso);
    return inscripcion ? Inscripcion.fromDatabase(inscripcion) : null;
  }

  deleteInscripcion(id) {
    const success = this.db.deleteInscripcion(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = InscripcionController;
