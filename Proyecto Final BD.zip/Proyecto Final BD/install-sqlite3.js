#!/usr/bin/env node
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const nodeModulesPath = path.join(__dirname, 'node_modules');
const sqlite3Path = path.join(nodeModulesPath, 'sqlite3');

// Check if sqlite3 is already installed
if (fs.existsSync(sqlite3Path)) {
    console.log('✅ sqlite3 ya está instalado');
    process.exit(0);
}

console.log('📦 Instalando sqlite3...');
try {
    // Try to install with npm
    execSync('npm install sqlite3 --save', { 
        cwd: path.join(__dirname),
        stdio: 'inherit'
    });
    console.log('✅ sqlite3 instalado exitosamente');
} catch (error) {
    console.error('❌ Error al instalar sqlite3:', error.message);
    
    // Try alternative using node directly
    console.log('Intentando instalación alternativa...');
    try {
        execSync('node -e "require(\\"child_process\\").execSync(\\"npm install sqlite3 --save\\", {stdio: \\"inherit\\"})"', {
            cwd: path.join(__dirname),
            stdio: 'inherit'
        });
    } catch (altError) {
        console.error('❌ Instalación alternativa también falló');
        process.exit(1);
    }
}
