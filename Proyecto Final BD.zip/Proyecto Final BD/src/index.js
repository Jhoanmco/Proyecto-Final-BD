require('dotenv').config();
const express = require('express');
const path = require('path');
const Database = require('./db/database');
const setupRoutes = require('./api/routes');
const { initializeSchema } = require('./utils/schema');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || './data/database.json';

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  if (req.method === 'OPTIONS') res.sendStatus(200);
  else next();
});

// Initialize application
try {
  // Initialize database
  const database = new Database(DB_PATH);
  database.init();
  initializeSchema(database);

  // Setup routes
  setupRoutes(app, database);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Database Interface API is running' });
  });

  // Root route
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
  });

  // Start server
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Database: ${DB_PATH}`);
    console.log(`Visit http://localhost:${PORT}/api/health to check server status`);
  });

  // Handle shutdown
  process.on('SIGINT', () => {
    console.log('\nShutting down...');
    database.close();
    process.exit(0);
  });
} catch (error) {
  console.error('Failed to start server:', error);
  process.exit(1);
}
