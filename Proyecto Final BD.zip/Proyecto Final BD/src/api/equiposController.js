const Equipos = require('../models/Equipos');

class EquiposController {
  constructor(database) {
    this.db = database;
  }

  getAllEquipos() {
    const rows = this.db.getAllEquipos();
    return rows.map(row => Equipos.fromDatabase(row));
  }

  getEquiposById(id) {
    const row = this.db.getEquiposById(id);
    return row ? Equipos.fromDatabase(row) : null;
  }

  createEquipos(nombre, tipo, cantidad, espacioId) {
    const equipos = this.db.createEquipos(nombre, tipo, cantidad, espacioId);
    return Equipos.fromDatabase(equipos);
  }

  updateEquipos(id, nombre, tipo, cantidad, espacioId) {
    const equipos = this.db.updateEquipos(id, nombre, tipo, cantidad, espacioId);
    return equipos ? Equipos.fromDatabase(equipos) : null;
  }

  deleteEquipos(id) {
    const success = this.db.deleteEquipos(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = EquiposController;
