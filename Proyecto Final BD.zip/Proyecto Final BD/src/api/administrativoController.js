const Disponible = require('../models/Disponible');

class DisponibleController {
  constructor(database) {
    this.db = database;
  }

  getAllDisponibles() {
    const rows = this.db.getAllDisponibles();
    return rows.map(row => Disponible.fromDatabase(row));
  }

  getDisponibleById(id) {
    const row = this.db.getDisponibleById(id);
    return row ? Disponible.fromDatabase(row) : null;
  }

  createDisponible(espacioId, horarioId, disponible) {
    const disp = this.db.createDisponible(espacioId, horarioId, disponible);
    return Disponible.fromDatabase(disp);
  }

  updateDisponible(id, espacioId, horarioId, disponible) {
    const disp = this.db.updateDisponible(id, espacioId, horarioId, disponible);
    return disp ? Disponible.fromDatabase(disp) : null;
  }

  deleteDisponible(id) {
    const success = this.db.deleteDisponible(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = DisponibleController;
