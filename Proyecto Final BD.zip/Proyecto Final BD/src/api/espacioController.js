const Estudiante = require('../models/Estudiante');

class EstudianteController {
  constructor(database) {
    this.db = database;
  }

  getAllEstudiantes() {
    const rows = this.db.getAllEstudiantes();
    return rows.map(row => Estudiante.fromDatabase(row));
  }

  getEstudianteById(id) {
    const row = this.db.getEstudianteById(id);
    return row ? Estudiante.fromDatabase(row) : null;
  }

  createEstudiante(nombre, email, matricula, cursoId) {
    const estudiante = this.db.createEstudiante(nombre, email, matricula, cursoId);
    return Estudiante.fromDatabase(estudiante);
  }

  updateEstudiante(id, nombre, email, matricula, cursoId) {
    const estudiante = this.db.updateEstudiante(id, nombre, email, matricula, cursoId);
    return estudiante ? Estudiante.fromDatabase(estudiante) : null;
  }

  deleteEstudiante(id) {
    const success = this.db.deleteEstudiante(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = EstudianteController;
