require('dotenv').config();
const express = require('express');
const path = require('path');
const Database = require('./db/database');
const setupRoutes = require('./api/routes');
const { initializeSchema } = require('./utils/schema');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  if (req.method === 'OPTIONS') res.sendStatus(200);
  else next();
});

// Initialize application
async function startServer() {
  try {
    // Initialize database
    const database = new Database();
    await database.init();
    
    initializeSchema(database);

    // Setup routes
    setupRoutes(app, database);

    // Health check endpoint
    app.get('/api/health', (req, res) => {
      res.json({ status: 'OK', message: 'Database Interface API is running' });
    });

    // Root route
    app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, '../public/index.html'));
    });

    // Start server
    app.listen(PORT, () => {
      console.log(`\n🚀 Servidor ejecutándose en puerto ${PORT}`);
      console.log(`💾 Base de datos: JSON local (./data/database.json)`);
      console.log(`📍 Acceder a: http://localhost:${PORT}`);
      console.log(`🏥 Health check: http://localhost:${PORT}/api/health\n`);
    });

    // Handle shutdown
    process.on('SIGINT', async () => {
      console.log('\n⛔ Apagando servidor...');
      await database.close();
      process.exit(0);
    });

  } catch (error) {
    console.error('❌ Error al iniciar el servidor:', error);
    process.exit(1);
  }
}

startServer();
