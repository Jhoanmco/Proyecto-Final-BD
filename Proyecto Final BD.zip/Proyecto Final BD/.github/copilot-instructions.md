# Copilot Instructions for Database Interface Project

This is a JavaScript database interface project built with Node.js and Express.

## Project Overview

- **Type:** Node.js Backend API
- **Language:** JavaScript
- **Database:** SQLite
- **Framework:** Express.js
- **Main Purpose:** Provide a clean REST API interface for database operations

## Key Files and Structure

- `src/db/database.js` - Core database wrapper with async methods
- `src/api/` - REST API routes and controllers
- `src/models/` - Data models (User, etc.)
- `src/utils/` - Utilities like schema initialization
- `package.json` - Project dependencies

## Development Workflow

1. Install dependencies: `npm install`
2. Create `.env` file from `.env.example`
3. Start development: `npm run dev`
4. Run tests: `npm test`

## Adding New Features

When adding new database models:
1. Create a model file in `src/models/`
2. Create a controller in `src/api/`
3. Add routes in `src/api/routes.js`
4. Update schema in `src/utils/schema.js`

## Current Dependencies

- express: ^4.18.2
- sqlite3: ^5.1.6
- dotenv: ^16.3.1
- nodemon: ^3.0.1 (dev)
- jest: ^29.7.0 (dev)
