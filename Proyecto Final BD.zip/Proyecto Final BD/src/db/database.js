const fs = require('fs');
const path = require('path');

const JSON_DB_PATH = path.join(__dirname, '../../data/database.json');

class Database {
    constructor() {
        this.data = {
            usuarios: [],
            profesores: [],
            cursos: [],
            estudiantes: [],
            espacios: [],
            equipos: [],
            asignaciones: [],
            horarios: [],
            disponibles: [],
            administrativos: [],
            inscripcion: []
        };
        this.initialized = false;
    }

    async init() {
        try {
            this.ensureDataDir();
            if (fs.existsSync(JSON_DB_PATH)) {
                const content = fs.readFileSync(JSON_DB_PATH, 'utf8');
                this.data = JSON.parse(content);
                console.log('✅ Base de datos cargada desde archivo JSON');
            } else {
                this.save();
                console.log('✅ Nueva base de datos creada');
            }
            this.initialized = true;
        } catch (error) {
            console.error('❌ Error inicializando base de datos:', error);
            throw error;
        }
    }

    ensureDataDir() {
        const dir = path.dirname(JSON_DB_PATH);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    save() {
        try {
            this.ensureDataDir();
            fs.writeFileSync(JSON_DB_PATH, JSON.stringify(this.data, null, 2));
        } catch (error) {
            console.error('Error guardando datos:', error);
        }
    }

    getNextId(entityName) {
        const items = this.data[entityName] || [];
        if (items.length === 0) return 1;
        return Math.max(...items.map(i => i.id || 0)) + 1;
    }

    // ==================== USUARIOS ====================
    getAllUsers() {
        return (this.data.usuarios || []).filter(u => u.activo !== false);
    }

    getUserById(id) {
        return (this.data.usuarios || []).find(u => u.id === parseInt(id) && u.activo !== false);
    }

    createUser(user) {
        const newUser = { ...user, id: this.getNextId('usuarios'), activo: true };
        this.data.usuarios.push(newUser);
        this.save();
        return newUser;
    }

    updateUser(id, user) {
        const index = (this.data.usuarios || []).findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
            this.data.usuarios[index] = { ...this.data.usuarios[index], ...user };
            this.save();
        }
    }

    deleteUser(id) {
        const index = (this.data.usuarios || []).findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
            this.data.usuarios[index].activo = false;
            this.save();
        }
    }

    // ==================== PROFESORES ====================
    getAllProfesores() {
        return (this.data.profesores || []).filter(p => p.activo !== false);
    }

    getProfesorById(id) {
        return (this.data.profesores || []).find(p => p.id === parseInt(id) && p.activo !== false);
    }

    createProfesor(profesor) {
        const newProfesor = { ...profesor, id: this.getNextId('profesores'), activo: true, createdAt: new Date().toISOString() };
        this.data.profesores.push(newProfesor);
        this.save();
        return newProfesor;
    }

    updateProfesor(id, profesor) {
        const index = (this.data.profesores || []).findIndex(p => p.id === parseInt(id));
        if (index !== -1) {
            this.data.profesores[index] = { ...this.data.profesores[index], ...profesor };
            this.save();
        }
    }

    deleteProfesor(id) {
        const index = (this.data.profesores || []).findIndex(p => p.id === parseInt(id));
        if (index !== -1) {
            this.data.profesores[index].activo = false;
            this.save();
        }
    }

    // ==================== CURSOS ====================
    getAllCursos() {
        return (this.data.cursos || []).filter(c => c.activo !== false);
    }

    getCursoById(id) {
        return (this.data.cursos || []).find(c => c.id === parseInt(id) && c.activo !== false);
    }

    createCurso(curso) {
        const newCurso = { ...curso, id: this.getNextId('cursos'), activo: true, createdAt: new Date().toISOString() };
        this.data.cursos.push(newCurso);
        this.save();
        return newCurso;
    }

    updateCurso(id, curso) {
        const index = (this.data.cursos || []).findIndex(c => c.id === parseInt(id));
        if (index !== -1) {
            this.data.cursos[index] = { ...this.data.cursos[index], ...curso };
            this.save();
        }
    }

    deleteCurso(id) {
        const index = (this.data.cursos || []).findIndex(c => c.id === parseInt(id));
        if (index !== -1) {
            this.data.cursos[index].activo = false;
            this.save();
        }
    }

    // ==================== ESTUDIANTES ====================
    getAllEstudiantes() {
        return (this.data.estudiantes || []).filter(e => e.activo !== false);
    }

    getEstudianteById(id) {
        return (this.data.estudiantes || []).find(e => e.id === parseInt(id) && e.activo !== false);
    }

    createEstudiante(estudiante) {
        const newEstudiante = { ...estudiante, id: this.getNextId('estudiantes'), activo: true, createdAt: new Date().toISOString() };
        this.data.estudiantes.push(newEstudiante);
        this.save();
        return newEstudiante;
    }

    updateEstudiante(id, estudiante) {
        const index = (this.data.estudiantes || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.estudiantes[index] = { ...this.data.estudiantes[index], ...estudiante };
            this.save();
        }
    }

    deleteEstudiante(id) {
        const index = (this.data.estudiantes || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.estudiantes[index].activo = false;
            this.save();
        }
    }

    // ==================== ESPACIOS ====================
    getAllEspacios() {
        return (this.data.espacios || []).filter(e => e.activo !== false);
    }

    getEspacioById(id) {
        return (this.data.espacios || []).find(e => e.id === parseInt(id) && e.activo !== false);
    }

    createEspacio(espacio) {
        const newEspacio = { ...espacio, id: this.getNextId('espacios'), activo: true, createdAt: new Date().toISOString() };
        this.data.espacios.push(newEspacio);
        this.save();
        return newEspacio;
    }

    updateEspacio(id, espacio) {
        const index = (this.data.espacios || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.espacios[index] = { ...this.data.espacios[index], ...espacio };
            this.save();
        }
    }

    deleteEspacio(id) {
        const index = (this.data.espacios || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.espacios[index].activo = false;
            this.save();
        }
    }

    // ==================== EQUIPOS ====================
    getAllEquipos() {
        return (this.data.equipos || []).filter(e => e.activo !== false);
    }

    getEquipoById(id) {
        return (this.data.equipos || []).find(e => e.id === parseInt(id) && e.activo !== false);
    }

    createEquipo(equipo) {
        const newEquipo = { ...equipo, id: this.getNextId('equipos'), activo: true, createdAt: new Date().toISOString() };
        this.data.equipos.push(newEquipo);
        this.save();
        return newEquipo;
    }

    updateEquipo(id, equipo) {
        const index = (this.data.equipos || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.equipos[index] = { ...this.data.equipos[index], ...equipo };
            this.save();
        }
    }

    deleteEquipo(id) {
        const index = (this.data.equipos || []).findIndex(e => e.id === parseInt(id));
        if (index !== -1) {
            this.data.equipos[index].activo = false;
            this.save();
        }
    }

    // ==================== ASIGNACIONES ====================
    getAllAsignaciones() {
        return (this.data.asignaciones || []).filter(a => a.activo !== false);
    }

    getAsignacionById(id) {
        return (this.data.asignaciones || []).find(a => a.id === parseInt(id) && a.activo !== false);
    }

    createAsignacion(asignacion) {
        const newAsignacion = { ...asignacion, id: this.getNextId('asignaciones'), activo: true, createdAt: new Date().toISOString() };
        this.data.asignaciones.push(newAsignacion);
        this.save();
        return newAsignacion;
    }

    updateAsignacion(id, asignacion) {
        const index = (this.data.asignaciones || []).findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
            this.data.asignaciones[index] = { ...this.data.asignaciones[index], ...asignacion };
            this.save();
        }
    }

    deleteAsignacion(id) {
        const index = (this.data.asignaciones || []).findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
            this.data.asignaciones[index].activo = false;
            this.save();
        }
    }

    // ==================== HORARIOS ====================
    getAllHorarios() {
        return (this.data.horarios || []).filter(h => h.activo !== false);
    }

    getHorarioById(id) {
        return (this.data.horarios || []).find(h => h.id === parseInt(id) && h.activo !== false);
    }

    createHorario(horario) {
        const newHorario = { ...horario, id: this.getNextId('horarios'), activo: true, createdAt: new Date().toISOString() };
        this.data.horarios.push(newHorario);
        this.save();
        return newHorario;
    }

    updateHorario(id, horario) {
        const index = (this.data.horarios || []).findIndex(h => h.id === parseInt(id));
        if (index !== -1) {
            this.data.horarios[index] = { ...this.data.horarios[index], ...horario };
            this.save();
        }
    }

    deleteHorario(id) {
        const index = (this.data.horarios || []).findIndex(h => h.id === parseInt(id));
        if (index !== -1) {
            this.data.horarios[index].activo = false;
            this.save();
        }
    }

    // ==================== DISPONIBLES ====================
    getAllDisponibles() {
        return (this.data.disponibles || []).filter(d => d.activo !== false);
    }

    getDisponibleById(id) {
        return (this.data.disponibles || []).find(d => d.id === parseInt(id) && d.activo !== false);
    }

    createDisponible(disponible) {
        const newDisponible = { ...disponible, id: this.getNextId('disponibles'), activo: true, createdAt: new Date().toISOString() };
        this.data.disponibles.push(newDisponible);
        this.save();
        return newDisponible;
    }

    updateDisponible(id, disponible) {
        const index = (this.data.disponibles || []).findIndex(d => d.id === parseInt(id));
        if (index !== -1) {
            this.data.disponibles[index] = { ...this.data.disponibles[index], ...disponible };
            this.save();
        }
    }

    deleteDisponible(id) {
        const index = (this.data.disponibles || []).findIndex(d => d.id === parseInt(id));
        if (index !== -1) {
            this.data.disponibles[index].activo = false;
            this.save();
        }
    }

    // ==================== ADMINISTRATIVOS ====================
    getAllAdministrativos() {
        return (this.data.administrativos || []).filter(a => a.activo !== false);
    }

    getAdministrativoById(id) {
        return (this.data.administrativos || []).find(a => a.id === parseInt(id) && a.activo !== false);
    }

    createAdministrativo(administrativo) {
        const newAdministrativo = { ...administrativo, id: this.getNextId('administrativos'), activo: true, createdAt: new Date().toISOString() };
        this.data.administrativos.push(newAdministrativo);
        this.save();
        return newAdministrativo;
    }

    updateAdministrativo(id, administrativo) {
        const index = (this.data.administrativos || []).findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
            this.data.administrativos[index] = { ...this.data.administrativos[index], ...administrativo };
            this.save();
        }
    }

    deleteAdministrativo(id) {
        const index = (this.data.administrativos || []).findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
            this.data.administrativos[index].activo = false;
            this.save();
        }
    }

    // ==================== INSCRIPCIÓN ====================
    getAllInscripciones() {
        return (this.data.inscripcion || []).filter(i => i.activo !== false);
    }

    getInscripcionById(id) {
        return (this.data.inscripcion || []).find(i => i.id === parseInt(id) && i.activo !== false);
    }

    createInscripcion(id_estudiante, id_curso) {
        const newInscripcion = { 
            id: this.getNextId('inscripcion'), 
            id_estudiante, 
            id_curso, 
            activo: true, 
            createdAt: new Date().toISOString() 
        };
        this.data.inscripcion.push(newInscripcion);
        this.save();
        return newInscripcion;
    }

    updateInscripcion(id, id_estudiante, id_curso) {
        const index = (this.data.inscripcion || []).findIndex(i => i.id === parseInt(id));
        if (index !== -1) {
            this.data.inscripcion[index] = { 
                ...this.data.inscripcion[index], 
                id_estudiante, 
                id_curso 
            };
            this.save();
            return this.data.inscripcion[index];
        }
        return null;
    }

    deleteInscripcion(id) {
        const index = (this.data.inscripcion || []).findIndex(i => i.id === parseInt(id));
        if (index !== -1) {
            this.data.inscripcion[index].activo = false;
            this.save();
            return true;
        }
        return false;
    }

    async close() {
        this.save();
        console.log('✅ Base de datos cerrada');
    }
}

module.exports = Database;
