const Horario = require('../models/Horario');

class HorarioController {
  constructor(database) {
    this.db = database;
  }

  getAllHorarios() {
    const rows = this.db.getAllHorarios();
    return rows.map(row => Horario.fromDatabase(row));
  }

  getHorarioById(id) {
    const row = this.db.getHorarioById(id);
    return row ? Horario.fromDatabase(row) : null;
  }

  createHorario(asignacionId, diaSemana, horaInicio, horaFin) {
    const horario = this.db.createHorario(asignacionId, diaSemana, horaInicio, horaFin);
    return Horario.fromDatabase(horario);
  }

  updateHorario(id, asignacionId, diaSemana, horaInicio, horaFin) {
    const horario = this.db.updateHorario(id, asignacionId, diaSemana, horaInicio, horaFin);
    return horario ? Horario.fromDatabase(horario) : null;
  }

  deleteHorario(id) {
    const success = this.db.deleteHorario(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = HorarioController;
