const Database = require('./src/db/database');

const database = new Database('./data/database.json');
database.init();

// Crear Profesores
const prof1 = database.createProfesor('Dr. Juan Pérez', 'juan.perez@example.com', 'Matemáticas');
const prof2 = database.createProfesor('Dra. María García', 'maria.garcia@example.com', 'Física');
const prof3 = database.createProfesor('Ing. Carlos López', 'carlos.lopez@example.com', 'Programación');

console.log('✓ 3 Profesores creados');

// Crear Espacios
const esp1 = database.createEspacio('Aula 101', 'Piso 1', 30, 'Salón');
const esp2 = database.createEspacio('Laboratorio 205', 'Piso 2', 20, 'Laboratorio');
const esp3 = database.createEspacio('Aula 301', 'Piso 3', 35, 'Salón');

console.log('✓ 3 Espacios creados');

// Crear Cursos
const curso1 = database.createCurso('Cálculo I', 'MAT101', 'Introducción al cálculo', prof1.id);
const curso2 = database.createCurso('Física General', 'FIS101', 'Conceptos básicos de física', prof2.id);
const curso3 = database.createCurso('Programación Web', 'PRG101', 'Desarrollo web moderno', prof3.id);

console.log('✓ 3 Cursos creados');

// Crear Estudiantes
const est1 = database.createEstudiante('Pedro Martínez', 'pedro@example.com', 'EST001', curso1.id);
const est2 = database.createEstudiante('Laura Rodríguez', 'laura@example.com', 'EST002', curso2.id);
const est3 = database.createEstudiante('Miguel Sánchez', 'miguel@example.com', 'EST003', curso3.id);

console.log('✓ 3 Estudiantes creados');

// Crear Equipos
const eq1 = database.createEquipos('Proyector', 'AV', 2, esp1.id);
const eq2 = database.createEquipos('Computadoras', 'Cómputo', 15, esp2.id);
const eq3 = database.createEquipos('Pizarra Blanca', 'Escritorio', 3, esp3.id);

console.log('✓ 3 Equipos creados');

// Crear Asignaciones
const asig1 = database.createAsignacion(curso1.id, esp1.id);
const asig2 = database.createAsignacion(curso2.id, esp2.id);
const asig3 = database.createAsignacion(curso3.id, esp3.id);

console.log('✓ 3 Asignaciones creadas');

// Crear Horarios
const hor1 = database.createHorario(asig1.id, 'Lunes', '08:00', '10:00');
const hor2 = database.createHorario(asig2.id, 'Martes', '10:00', '12:00');
const hor3 = database.createHorario(asig3.id, 'Miércoles', '14:00', '16:00');

console.log('✓ 3 Horarios creados');

// Crear Disponibles
const disp1 = database.createDisponible(esp1.id, hor1.id, true);
const disp2 = database.createDisponible(esp2.id, hor2.id, true);
const disp3 = database.createDisponible(esp3.id, hor3.id, false);

console.log('✓ 3 Disponibles creados');

// Crear Administrativos
const admin1 = database.createAdministrativo('Roberto Gerente', 'roberto@example.com', 'Director');
const admin2 = database.createAdministrativo('Sandra Secretaria', 'sandra@example.com', 'Secretaria');
const admin3 = database.createAdministrativo('Luis Mantenimiento', 'luis@example.com', 'Mantenimiento');

console.log('✓ 3 Administrativos creados');

console.log('\n========================================');
console.log('✓ Base de datos llenada exitosamente!');
console.log('========================================');

database.close();
