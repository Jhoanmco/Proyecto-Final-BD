class Estudiante {
  constructor(id, nombre, email, matricula, cursoId, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
    this.matricula = matricula;
    this.cursoId = cursoId;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      email: this.email,
      matricula: this.matricula,
      cursoId: this.cursoId,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Estudiante(row.id, row.nombre, row.email, row.matricula, row.cursoId, row.createdAt);
  }
}

module.exports = Estudiante;
