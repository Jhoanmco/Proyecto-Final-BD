class Profesor {
  constructor(id, nombre, email, telefono = '', numero_documento = '', departamento = '', especialidad = '', createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
    this.telefono = telefono;
    this.numero_documento = numero_documento;
    this.departamento = departamento;
    this.especialidad = especialidad;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      email: this.email,
      telefono: this.telefono,
      numero_documento: this.numero_documento,
      departamento: this.departamento,
      especialidad: this.especialidad,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Profesor(row.id, row.nombre, row.email, row.telefono, row.numero_documento, row.departamento, row.especialidad, row.createdAt);
  }
}

module.exports = Profesor;
