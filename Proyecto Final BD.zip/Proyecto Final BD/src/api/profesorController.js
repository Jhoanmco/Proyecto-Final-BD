const Profesor = require('../models/Profesor');

class ProfesorController {
  constructor(database) {
    this.db = database;
  }

  getAllProfesores() {
    const rows = this.db.getAllProfesores();
    return rows.map(row => Profesor.fromDatabase(row));
  }

  getProfesorById(id) {
    const row = this.db.getProfesorById(id);
    return row ? Profesor.fromDatabase(row) : null;
  }

  createProfesor(nombre, email, especialidad) {
    const profesor = this.db.createProfesor(nombre, email, especialidad);
    return Profesor.fromDatabase(profesor);
  }

  updateProfesor(id, nombre, email, especialidad) {
    const profesor = this.db.updateProfesor(id, nombre, email, especialidad);
    return profesor ? Profesor.fromDatabase(profesor) : null;
  }

  deleteProfesor(id) {
    const success = this.db.deleteProfesor(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = ProfesorController;
