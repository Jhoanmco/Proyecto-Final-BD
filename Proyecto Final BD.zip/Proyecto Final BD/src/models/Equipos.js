class Equipos {
  constructor(id, nombre, tipo, cantidad, espacioId, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.cantidad = cantidad;
    this.espacioId = espacioId;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      tipo: this.tipo,
      cantidad: this.cantidad,
      espacioId: this.espacioId,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Equipos(row.id, row.nombre, row.tipo, row.cantidad, row.espacioId, row.createdAt);
  }
}

module.exports = Equipos;
