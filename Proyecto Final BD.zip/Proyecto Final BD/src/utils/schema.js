/**
 * Initialize database schema (not needed for JSON storage)
 */
function initializeSchema(database) {
  console.log('Database schema initialized');
}

module.exports = { initializeSchema };
