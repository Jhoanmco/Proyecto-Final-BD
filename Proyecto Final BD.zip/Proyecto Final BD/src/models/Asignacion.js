class Asignacion {
  constructor(id, cursoId, espacioId, createdAt = new Date().toISOString()) {
    this.id = id;
    this.cursoId = cursoId;
    this.espacioId = espacioId;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      cursoId: this.cursoId,
      espacioId: this.espacioId,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Asignacion(row.id, row.cursoId, row.espacioId, row.createdAt);
  }
}

module.exports = Asignacion;
