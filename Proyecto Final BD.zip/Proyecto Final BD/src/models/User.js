class User {
  constructor(id, name, email, createdAt = new Date().toISOString()) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      email: this.email,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new User(row.id, row.name, row.email, row.created_at || row.createdAt);
  }
}

module.exports = User;
