class Estudiante {
  constructor(id, nombre, numero_documento, curso, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.numero_documento = numero_documento;
    this.curso = curso;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      numero_documento: this.numero_documento,
      curso: this.curso,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Estudiante(row.id, row.nombre, row.numero_documento, row.curso, row.createdAt);
  }
}

module.exports = Estudiante;
