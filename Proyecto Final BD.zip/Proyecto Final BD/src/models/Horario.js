class Horario {
  constructor(id, asignacionId, diaSemana, horaInicio, horaFin, createdAt = new Date().toISOString()) {
    this.id = id;
    this.asignacionId = asignacionId;
    this.diaSemana = diaSemana;
    this.horaInicio = horaInicio;
    this.horaFin = horaFin;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      asignacionId: this.asignacionId,
      diaSemana: this.diaSemana,
      horaInicio: this.horaInicio,
      horaFin: this.horaFin,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Horario(row.id, row.asignacionId, row.diaSemana, row.horaInicio, row.horaFin, row.createdAt);
  }
}

module.exports = Horario;
