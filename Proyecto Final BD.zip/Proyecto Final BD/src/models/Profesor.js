class Profesor {
  constructor(id, nombre, email, especialidad, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
    this.especialidad = especialidad;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      email: this.email,
      especialidad: this.especialidad,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Profesor(row.id, row.nombre, row.email, row.especialidad, row.createdAt);
  }
}

module.exports = Profesor;
