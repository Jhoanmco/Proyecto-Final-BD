const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '../../data/database.db');

class SQLiteDatabase {
    constructor() {
        this.db = null;
    }

    initialize() {
        return new Promise((resolve, reject) => {
            this.db = new sqlite3.Database(DB_PATH, (err) => {
                if (err) {
                    console.error('Error al conectar a SQLite:', err);
                    reject(err);
                } else {
                    console.log('✅ Conectado a SQLite:', DB_PATH);
                    this.createTables().then(resolve).catch(reject);
                }
            });
        });
    }

    createTables() {
        return new Promise((resolve, reject) => {
            this.db.serialize(() => {
                // Tabla Usuarios
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS usuarios (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        email TEXT NOT NULL UNIQUE,
                        contraseña TEXT,
                        rol TEXT DEFAULT 'usuario',
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Profesores
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS profesores (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        email TEXT NOT NULL UNIQUE,
                        telefono TEXT,
                        numero_documento TEXT,
                        departamento TEXT,
                        especialidad TEXT,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Cursos
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS cursos (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_curso TEXT NOT NULL,
                        codigo TEXT NOT NULL UNIQUE,
                        num_estudiantes INTEGER,
                        id_profesor INTEGER,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (id_profesor) REFERENCES profesores(id)
                    )
                `);

                // Tabla Estudiantes
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS estudiantes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        numero_documento TEXT NOT NULL UNIQUE,
                        curso TEXT,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Espacios
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS espacios (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        tipo TEXT NOT NULL,
                        capacidad INTEGER NOT NULL,
                        ubicacion TEXT,
                        estado TEXT DEFAULT 'Disponible',
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Equipos
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS equipos (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        tipo TEXT NOT NULL,
                        serie TEXT,
                        estado BOOLEAN DEFAULT 1,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Asignaciones
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS asignaciones (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_espacio INTEGER,
                        id_curso INTEGER,
                        id_profesor INTEGER,
                        id_estudiante INTEGER,
                        id_administrativo INTEGER,
                        fecha_asignacion TEXT,
                        estado TEXT DEFAULT 'Activa',
                        tipo_solicitnte TEXT,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (id_espacio) REFERENCES espacios(id),
                        FOREIGN KEY (id_curso) REFERENCES cursos(id),
                        FOREIGN KEY (id_profesor) REFERENCES profesores(id),
                        FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id),
                        FOREIGN KEY (id_administrativo) REFERENCES administrativos(id)
                    )
                `);

                // Tabla Horarios
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS horarios (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_asignacion INTEGER,
                        id_espacio INTEGER,
                        id_profesor INTEGER,
                        dia TEXT NOT NULL,
                        hora_inicio TEXT NOT NULL,
                        hora_fin TEXT NOT NULL,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (id_asignacion) REFERENCES asignaciones(id),
                        FOREIGN KEY (id_espacio) REFERENCES espacios(id),
                        FOREIGN KEY (id_profesor) REFERENCES profesores(id)
                    )
                `);

                // Tabla Disponibles
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS disponibles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_espacio INTEGER,
                        dia TEXT NOT NULL,
                        hora_inicio TEXT NOT NULL,
                        hora_fin TEXT NOT NULL,
                        razon TEXT,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (id_espacio) REFERENCES espacios(id)
                    )
                `);

                // Tabla Administrativos
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS administrativos (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT NOT NULL,
                        email TEXT,
                        telefono TEXT,
                        departamento TEXT,
                        activo BOOLEAN DEFAULT 1,
                        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Tabla Inscripción
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS inscripcion (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_estudiante INTEGER NOT NULL,
                        id_curso INTEGER NOT NULL,
                        fecha_inscripcion TEXT DEFAULT CURRENT_TIMESTAMP,
                        activo BOOLEAN DEFAULT 1,
                        FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id),
                        FOREIGN KEY (id_curso) REFERENCES cursos(id),
                        UNIQUE(id_estudiante, id_curso)
                    )
                `, (err) => {
                    if (err) {
                        console.error('Error al crear tablas:', err);
                        reject(err);
                    } else {
                        console.log('✅ Tablas creadas/verificadas correctamente');
                        resolve();
                    }
                });
            });
        });
    }

    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ lastID: this.lastID, changes: this.changes });
                }
            });
        });
    }

    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows || []);
                }
            });
        });
    }

    close() {
        return new Promise((resolve, reject) => {
            this.db.close((err) => {
                if (err) {
                    reject(err);
                } else {
                    console.log('✅ Conexión a SQLite cerrada');
                    resolve();
                }
            });
        });
    }
}

module.exports = SQLiteDatabase;
