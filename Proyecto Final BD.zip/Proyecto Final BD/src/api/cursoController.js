const Curso = require('../models/Curso');

class CursoController {
  constructor(database) {
    this.db = database;
  }

  getAllCursos() {
    const rows = this.db.getAllCursos();
    return rows.map(row => Curso.fromDatabase(row));
  }

  getCursoById(id) {
    const row = this.db.getCursoById(id);
    return row ? Curso.fromDatabase(row) : null;
  }

  createCurso(nombre, codigo, descripcion, profesorId) {
    const curso = this.db.createCurso(nombre, codigo, descripcion, profesorId);
    return Curso.fromDatabase(curso);
  }

  updateCurso(id, nombre, codigo, descripcion, profesorId) {
    const curso = this.db.updateCurso(id, nombre, codigo, descripcion, profesorId);
    return curso ? Curso.fromDatabase(curso) : null;
  }

  deleteCurso(id) {
    const success = this.db.deleteCurso(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = CursoController;
