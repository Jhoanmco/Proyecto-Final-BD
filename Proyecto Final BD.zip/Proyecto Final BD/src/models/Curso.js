class Curso {
  constructor(id, nombre_curso, codigo, num_estudiantes = 0, id_profesor = 1, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre_curso = nombre_curso;
    this.codigo = codigo;
    this.num_estudiantes = num_estudiantes;
    this.id_profesor = id_profesor;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre_curso: this.nombre_curso,
      codigo: this.codigo,
      num_estudiantes: this.num_estudiantes,
      id_profesor: this.id_profesor,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Curso(row.id, row.nombre_curso, row.codigo, row.num_estudiantes, row.id_profesor, row.createdAt);
  }
}

module.exports = Curso;
