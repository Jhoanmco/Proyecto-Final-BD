const Disponible = require('../models/Disponible');

class DisponibleController {
  constructor(database) {
    this.db = database;
  }

  getAllDisponibles() {
    const rows = this.db.getAllDisponibles();
    return rows.map(row => Disponible.fromDatabase(row));
  }

  getDisponibleById(id) {
    const row = this.db.getDisponibleById(id);
    return row ? Disponible.fromDatabase(row) : null;
  }

  createDisponible(espacioId, horarioId) {
    const disponible = this.db.createDisponible(espacioId, horarioId);
    return Disponible.fromDatabase(disponible);
  }

  updateDisponible(id, espacioId, horarioId) {
    const disponible = this.db.updateDisponible(id, espacioId, horarioId);
    return disponible ? Disponible.fromDatabase(disponible) : null;
  }

  deleteDisponible(id) {
    const success = this.db.deleteDisponible(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = DisponibleController;
