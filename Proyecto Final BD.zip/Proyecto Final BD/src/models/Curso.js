class Curso {
  constructor(id, nombre, codigo, descripcion, profesorId, createdAt = new Date().toISOString()) {
    this.id = id;
    this.nombre = nombre;
    this.codigo = codigo;
    this.descripcion = descripcion;
    this.profesorId = profesorId;
    this.createdAt = createdAt;
  }

  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      codigo: this.codigo,
      descripcion: this.descripcion,
      profesorId: this.profesorId,
      createdAt: this.createdAt
    };
  }

  static fromDatabase(row) {
    return new Curso(row.id, row.nombre, row.codigo, row.descripcion, row.profesorId, row.createdAt);
  }
}

module.exports = Curso;
