const Asignacion = require('../models/Asignacion');

class AsignacionController {
  constructor(database) {
    this.db = database;
  }

  getAllAsignaciones() {
    const rows = this.db.getAllAsignaciones();
    return rows.map(row => Asignacion.fromDatabase(row));
  }

  getAsignacionById(id) {
    const row = this.db.getAsignacionById(id);
    return row ? Asignacion.fromDatabase(row) : null;
  }

  createAsignacion(cursoId, espacioId) {
    const asignacion = this.db.createAsignacion(cursoId, espacioId);
    return Asignacion.fromDatabase(asignacion);
  }

  updateAsignacion(id, cursoId, espacioId) {
    const asignacion = this.db.updateAsignacion(id, cursoId, espacioId);
    return asignacion ? Asignacion.fromDatabase(asignacion) : null;
  }

  deleteAsignacion(id) {
    const success = this.db.deleteAsignacion(id);
    return { success, id: parseInt(id) };
  }
}

module.exports = AsignacionController;
